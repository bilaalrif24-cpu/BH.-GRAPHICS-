BH GRAPHICS website
- Edit prices, services and contacts in the "EDIT HERE" block near the top of the script in index.html.
- Upload ALL files in this folder to an HTTPS host (Netlify, Cloudflare Pages, GitHub Pages). Keep them in the same folder.
- The app (PWA) install and offline mode only work on HTTPS or localhost, not when opening index.html from files.
